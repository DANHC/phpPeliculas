-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jun 09, 2017 at 05:09 PM
-- Server version: 5.6.35
-- PHP Version: 7.1.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sistemapelicula`
--
CREATE DATABASE IF NOT EXISTS `sistemapelicula` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `sistemapelicula`;

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`127.0.0.1` PROCEDURE `uspActualizarPelicula` (`vnombre` VARCHAR(200), `vidCat` INT, `vanio` INT(4), `vprotagonista` VARCHAR(200), `vduracion` VARCHAR(100), `vdirector` VARCHAR(200), `vplot` VARCHAR(500), `vkeywords` VARCHAR(200), `vprecio` DECIMAL(5,2), `vid` INT, `vestado` INT)  BEGIN
	
    UPDATE Pelicula SET
		Nombre = vnombre,
        idCategoria = vidCat,
        Anio = vanio,
        Protagonista = vprotagonista,
        Duracion = vduracion,
        Director = vdirector,
        Plot = vplot,
        KeyWords = vkeywords,
        Precio = vprecio,
        Disponible = vestado
	WHERE id = vid;
    
END$$

CREATE DEFINER=`root`@`127.0.0.1` PROCEDURE `uspRegistrarCliente` (`nombres` VARCHAR(100), `apellidos` VARCHAR(100), `edad` INT, `direccion` VARCHAR(300), `dui` VARCHAR(11), `telefono` VARCHAR(11), `sexo` CHAR(1), `nombreUsuario` VARCHAR(200), `contrasena` VARCHAR(400))  BEGIN

	INSERT INTO Usuario(Usuario, Contrasena, tipoUsuario)
    VALUES(nombreUsuario, contrasena, 'cliente');
    
    INSERT INTO Cliente(idUsuario, Nombres, Apellidos, Edad, Direccion, DUI, Telefono, Sexo)
    VALUES(LAST_INSERT_ID(), nombres, apellidos, edad, direccion, dui, telefono, sexo);
END$$

CREATE DEFINER=`root`@`127.0.0.1` PROCEDURE `uspRegistrarPelicula` (`vnombre` VARCHAR(200), `vidCat` INT, `vanio` INT(4), `vprotagonista` VARCHAR(200), `vduracion` VARCHAR(100), `vdirector` VARCHAR(200), `vimg` VARCHAR(400), `vplot` VARCHAR(500), `vkeywords` VARCHAR(200), `vprecio` DECIMAL(5,2))  BEGIN
	
    INSERT INTO Pelicula(Nombre, idCategoria, Anio, Protagonista, Duracion, Director, imgPath, Plot, KeyWords, Precio, Disponible)
    VALUES(vnombre, vidCat, vanio, vprotagonista, vduracion, vdirector, vimg, vplot, vkeywords, vprecio, 1);
	

END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `categoria`
--

CREATE TABLE `categoria` (
  `id` int(11) NOT NULL,
  `Nombre` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `categoria`
--

INSERT INTO `categoria` (`id`, `Nombre`) VALUES
(1, 'Accion'),
(2, 'Terror'),
(3, 'Suspenso'),
(4, 'Drama'),
(5, 'Anime'),
(6, 'Comedia'),
(7, 'Ciencia Ficción');

-- --------------------------------------------------------

--
-- Table structure for table `cliente`
--

CREATE TABLE `cliente` (
  `id` int(11) NOT NULL,
  `idUsuario` int(11) NOT NULL,
  `Nombres` varchar(100) NOT NULL,
  `Apellidos` varchar(100) NOT NULL,
  `Edad` int(11) NOT NULL,
  `Direccion` varchar(300) NOT NULL,
  `DUI` varchar(11) NOT NULL,
  `Telefono` varchar(11) NOT NULL,
  `Sexo` char(1) NOT NULL,
  `Eliminado` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cliente`
--

INSERT INTO `cliente` (`id`, `idUsuario`, `Nombres`, `Apellidos`, `Edad`, `Direccion`, `DUI`, `Telefono`, `Sexo`, `Eliminado`) VALUES
(1, 1, 'Mario Alberto', 'Guzman', 56, 'Final Miralvalle caserio el pepeto, #3', '12345678-9', '7676-2323', 'M', 0),
(2, 3, 'Juan Magan', 'Gerundio', 34, 'Residencial flor blanca, #45', '12345678-9', '6767-3456', 'M', 0),
(3, 4, 'Pedro Antonio', 'Del Hoyo', 34, 'Final el centro de SS, contiguo al capitolio', '12345678-9', '7676-4545', 'M', 0),
(4, 5, 'Daniel Antonio', 'Herrera Crespin', 21, 'Final Nuevo Lourdes, casa #45', '12345678-9', '7598-3423', 'M', 0),
(5, 6, 'Joseline Andrea', 'Rosales Rodriguez', 20, 'bdkjsbhes', '05838490-3', '2297-6884', 'F', 0);

-- --------------------------------------------------------

--
-- Table structure for table `compra`
--

CREATE TABLE `compra` (
  `id` int(11) NOT NULL,
  `idCliente` int(11) NOT NULL,
  `FechaCompra` date NOT NULL,
  `Total` decimal(10,2) DEFAULT NULL,
  `Pendiente` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `compra`
--

INSERT INTO `compra` (`id`, `idCliente`, `FechaCompra`, `Total`, `Pendiente`) VALUES
(2, 3, '2017-06-08', '134.87', 0),
(3, 3, '2017-06-09', '125.78', 0),
(4, 4, '2017-06-09', '115.78', 0),
(5, 5, '2017-06-09', '34.45', 0),
(6, 5, '2017-06-09', '91.96', 0);

-- --------------------------------------------------------

--
-- Table structure for table `detallecompra`
--

CREATE TABLE `detallecompra` (
  `idCompra` int(11) NOT NULL,
  `idPelicula` int(11) NOT NULL,
  `Precio` decimal(10,2) NOT NULL,
  `Cantidad` int(11) NOT NULL,
  `Total` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `detallecompra`
--

INSERT INTO `detallecompra` (`idCompra`, `idPelicula`, `Precio`, `Cantidad`, `Total`) VALUES
(2, 7, '34.99', 3, '104.97'),
(2, 8, '29.90', 1, '29.90'),
(3, 8, '29.90', 2, '59.80'),
(3, 9, '32.99', 2, '65.98'),
(4, 7, '34.99', 2, '69.98'),
(4, 10, '22.90', 2, '45.80'),
(5, 16, '34.45', 1, '34.45'),
(6, 7, '34.99', 2, '69.98'),
(6, 18, '10.99', 2, '21.98');

-- --------------------------------------------------------

--
-- Table structure for table `empleado`
--

CREATE TABLE `empleado` (
  `id` int(11) NOT NULL,
  `idUsuario` int(11) NOT NULL,
  `Nombres` varchar(100) NOT NULL,
  `Apellidos` varchar(100) NOT NULL,
  `Edad` int(11) NOT NULL,
  `Direccion` varchar(300) NOT NULL,
  `DUI` varchar(11) NOT NULL,
  `Telefono` varchar(11) NOT NULL,
  `Sexo` char(1) NOT NULL,
  `Eliminado` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `pedido`
--

CREATE TABLE `pedido` (
  `id` int(11) NOT NULL,
  `idProveedor` int(11) NOT NULL,
  `idEmpleado` int(11) NOT NULL,
  `FechaRealizacion` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `pedidodetalle`
--

CREATE TABLE `pedidodetalle` (
  `id` int(11) NOT NULL,
  `idPedido` int(11) NOT NULL,
  `NombrePelicula` varchar(200) NOT NULL,
  `Cantidad` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `pelicula`
--

CREATE TABLE `pelicula` (
  `id` int(11) NOT NULL,
  `Nombre` varchar(200) NOT NULL,
  `idCategoria` int(11) NOT NULL,
  `Anio` int(4) NOT NULL,
  `Protagonista` varchar(200) NOT NULL,
  `Duracion` varchar(100) NOT NULL,
  `Director` varchar(200) NOT NULL,
  `imgPath` varchar(400) DEFAULT NULL,
  `Plot` varchar(500) DEFAULT NULL,
  `KeyWords` varchar(200) DEFAULT NULL,
  `Precio` decimal(5,2) NOT NULL,
  `Disponible` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pelicula`
--

INSERT INTO `pelicula` (`id`, `Nombre`, `idCategoria`, `Anio`, `Protagonista`, `Duracion`, `Director`, `imgPath`, `Plot`, `KeyWords`, `Precio`, `Disponible`) VALUES
(7, 'Terminator 2', 1, 1984, 'Arnold Schwarzenegger', '2 horas', 'James Cameron', '../models/caratulas/Terminator.jpg', 'El día del juicio de las máquinas', 'Terminator, dia del juicio, robot', '34.99', 1),
(8, 'The Matrix', 1, 1990, 'Keanu Reeves', '2 horas', 'Lana Wachowski, Lilly Wachowski', '../models/caratulas/the_matrix.jpg', 'El mundo está controlado por una máquina superpoderosa', 'matrix, ficcion', '29.90', 1),
(9, 'La Cosa', 2, 1980, 'Kurt Rusell', '2:30 horas', 'John Carpenter', '../models/caratulas/the_thing.jpg', 'Un animal extraterrestre se pone a la caza de unos hombres en alaska', 'la cosa, fea, alien', '32.99', 1),
(10, 'El Hombre Elefante', 4, 1979, 'John Hurt', '2 horas', 'David Lynch', '../models/caratulas/elephant_man.jpg', 'Un hombre que padece de una severa deformidad es rescatado por un doctor que le brinda un hogar y también su amistad como amigo', 'elefante, hombre, deforme', '22.90', 1),
(11, 'Neon Genesis Evangelion', 5, 2001, 'Shinji Ikary', '3 años', 'Hideaki Anno', '../models/caratulas/neon.jpg', 'La tierra es asechada por una horda de espectros llamados \'Angeles\' que buscan la destrucción del planeta Tierra', 'anime', '10.90', 1),
(12, 'Solaris', 7, 1972, 'Friedrich Gorenstein', '1:30 horas', 'Andrei Tarkovsky', '../models/caratulas/solaris.jpg', 'Unos exploradores cósmicos buscan encontrar un planeta muy extraño que parece tener vida propia al que llaman Solaris', 'rusa', '55.30', 1),
(13, '1984', 7, 1984, 'John Hurt', '2 horas', 'Michael Radford', '../models/caratulas/1984.jpg', 'Esta película basada en la novela de George Orwell demuestra un panorama del mundo dominado por el fascismo y el totalitarismo en donde los ciudadanos son vigilados constantemente', 'fuccion', '23.45', 1),
(14, 'Akira', 5, 1988, ' Izo Hashimoto', '2 horas', ' Izo Hashimoto', '../models/caratulas/akira.jpg', 'Neo-Tokyo, 2019. Shotaro Kaneda sale junto con su pandilla de motociclistas (\"Los Cápsulas\") a pelear contra un pandilla rival conocida como Los Payasos. Sin embargo, el mejor amigo de Kaneda Tetsuo Shima sufre un accidente cuando choca su motocicleta contra Takashi, un niño esper que fue liberado un laboratorio secreto del gobierno por una organización revolucionaria clandestina disidente. Takashi es capturado por soldados armados, Tetsuo es hospitalizado. y la policía arresta a Kaneda y a su p', 'anime', '34.56', 1),
(15, 'EraserHead', 2, 1977, 'John Nance', '2 horas', 'David Lynch', '../models/caratulas/Eraserhead.jpg', 'La película presenta una trama poco convencional y la historia se desarrolla entre lo real y lo fantástico, lo grotesco y lo onírico. Fue filmada en blanco y negro, en un sórdido entorno de decadencia industrial, alrededor del personaje de Henry Spencer (interpretado por Jack Nance), un hombre nervioso y enigmático que trabaja en una imprenta y dice estar de vacaciones. Henry recibe un mensaje de Mary X, su ex pareja, quien lo invita a cenar en casa con sus padres. Henry se entera entonces de qu', 'ficcion', '23.11', 1),
(16, 'Depredador', 1, 1987, 'Arnold Schwarzenegger', '2 horas', 'John McTiernan', '../models/caratulas/kbxufopd.jpg', 'La película comienza mostrando una nave espacial acercándose a la Tierra, a continuación se muestra la costa de Guatemala donde un grupo de fuerzas especiales estadounidense comandado por el Delta Force Mayor Alan \"Dutch\" Schaeffer (Arnold Schwarzenegger) es enviado a rescatar a un ministro del gabinete presidencial secuestrado por un grupo guerrillero fuera del país. “Dutch” junto con un antiguo compañero de las Fuerzas Especiales del Ejército de Estados Unidos, actualmente perteneciente a la D', 'predator', '34.45', 1),
(17, 'La Morgue', 3, 2017, ' Ian B. Goldberg', '1:45 horas', 'André Øvredal', '../models/caratulas/23074.jpg', 'Cuando el cuerpo golpeado de una mujer no identificada es descubierto en un pequeño pueblo de Virginia, sucesos inexplicables comienzan a atormentar a los dueños de la morgue encargados de la autopsia de Jane Doe.', 'morgue', '22.45', 1),
(18, 'Scary Movie', 6, 2000, 'Marlon Wayans', '1:35 horas', 'Keenen Ivory Wayans', '../models/caratulas/scary.jpg', 'Una noche, la estudiante Drew Decker está preparando palomitas sola en su casa mientras espera a su novio para ver una película, cuando de repente un misterioso personaje la llama por teléfono con una voz grave y extraña. Inofensivo al principio, la persona que llama empieza a amenazar a Drew, diciéndole que él está observándola desnuda en las fotografías de una revista pornográfica.', 'scary', '10.99', 1);

-- --------------------------------------------------------

--
-- Table structure for table `proveedor`
--

CREATE TABLE `proveedor` (
  `id` int(11) NOT NULL,
  `Nombre` varchar(200) NOT NULL,
  `Eliminado` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `usuario`
--

CREATE TABLE `usuario` (
  `id` int(11) NOT NULL,
  `Usuario` varchar(200) NOT NULL,
  `Contrasena` varchar(400) NOT NULL,
  `tipoUsuario` varchar(25) NOT NULL,
  `Eliminado` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `usuario`
--

INSERT INTO `usuario` (`id`, `Usuario`, `Contrasena`, `tipoUsuario`, `Eliminado`) VALUES
(1, 'marito123', 'd6b8ea61d34096382cec8bb8dc45faf3', 'cliente', 0),
(2, 'admin', 'admin321', 'admin', 0),
(3, 'juancho', '2d26b90ec45179b65492eef3db8094e4', 'cliente', 0),
(4, 'pedrito', 'c59292ff37f107bd772319986993c1c6', 'cliente', 0),
(5, 'dahc', 'd93a5eba8f45e650a0ea799ec5632c47', 'cliente', 0),
(6, 'JRosales', '48aefa1cf3c961c0aaf81ebe12a1debc', 'cliente', 0);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vclientecompradetalle`
-- (See below for the actual view)
--
CREATE TABLE `vclientecompradetalle` (
`ClienteId` int(11)
,`Nombre` varchar(200)
,`imgPath` varchar(400)
,`Precio` decimal(10,2)
,`Cantidad` int(11)
,`SubTotal` decimal(10,2)
,`FechaCompra` varchar(10)
,`Total` decimal(10,2)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vcomprascliente`
-- (See below for the actual view)
--
CREATE TABLE `vcomprascliente` (
`id` int(11)
,`Cliente` varchar(201)
,`Direccion` varchar(300)
,`Telefono` varchar(11)
,`FechaCompra` varchar(10)
,`Total` decimal(10,2)
);

-- --------------------------------------------------------

--
-- Structure for view `vclientecompradetalle`
--
DROP TABLE IF EXISTS `vclientecompradetalle`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`127.0.0.1` SQL SECURITY DEFINER VIEW `vclientecompradetalle`  AS  select `c`.`id` AS `ClienteId`,`p`.`Nombre` AS `Nombre`,`p`.`imgPath` AS `imgPath`,`d`.`Precio` AS `Precio`,`d`.`Cantidad` AS `Cantidad`,`d`.`Total` AS `SubTotal`,date_format(`co`.`FechaCompra`,'%d-%m-%Y') AS `FechaCompra`,`co`.`Total` AS `Total` from (((`compra` `co` join `cliente` `c` on((`co`.`idCliente` = `c`.`id`))) join `detallecompra` `d` on((`co`.`id` = `d`.`idCompra`))) join `pelicula` `p` on((`p`.`id` = `d`.`idPelicula`))) where (`co`.`Pendiente` = 1) ;

-- --------------------------------------------------------

--
-- Structure for view `vcomprascliente`
--
DROP TABLE IF EXISTS `vcomprascliente`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`127.0.0.1` SQL SECURITY DEFINER VIEW `vcomprascliente`  AS  select `co`.`id` AS `id`,concat(`c`.`Nombres`,' ',`c`.`Apellidos`) AS `Cliente`,`c`.`Direccion` AS `Direccion`,`c`.`Telefono` AS `Telefono`,date_format(`co`.`FechaCompra`,'%d-%m-%Y') AS `FechaCompra`,`co`.`Total` AS `Total` from (`compra` `co` join `cliente` `c` on((`co`.`idCliente` = `c`.`id`))) where (`co`.`Pendiente` = 1) ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categoria`
--
ALTER TABLE `categoria`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cliente`
--
ALTER TABLE `cliente`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_Cliente_Usuario` (`idUsuario`);

--
-- Indexes for table `compra`
--
ALTER TABLE `compra`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_Compra_Cliente` (`idCliente`);

--
-- Indexes for table `detallecompra`
--
ALTER TABLE `detallecompra`
  ADD PRIMARY KEY (`idCompra`,`idPelicula`),
  ADD KEY `FK_DetalleCompra_Pelicula` (`idPelicula`);

--
-- Indexes for table `empleado`
--
ALTER TABLE `empleado`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_Empleado_Usuario` (`idUsuario`);

--
-- Indexes for table `pedido`
--
ALTER TABLE `pedido`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_Pedido_Proveedor` (`idProveedor`),
  ADD KEY `FK_Pedido_Empleado` (`idEmpleado`);

--
-- Indexes for table `pedidodetalle`
--
ALTER TABLE `pedidodetalle`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_PedidoDetalle_Pedido` (`idPedido`);

--
-- Indexes for table `pelicula`
--
ALTER TABLE `pelicula`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_Pelicula_Categoria` (`idCategoria`);

--
-- Indexes for table `proveedor`
--
ALTER TABLE `proveedor`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categoria`
--
ALTER TABLE `categoria`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `cliente`
--
ALTER TABLE `cliente`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `compra`
--
ALTER TABLE `compra`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `empleado`
--
ALTER TABLE `empleado`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pedido`
--
ALTER TABLE `pedido`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pedidodetalle`
--
ALTER TABLE `pedidodetalle`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pelicula`
--
ALTER TABLE `pelicula`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `proveedor`
--
ALTER TABLE `proveedor`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `usuario`
--
ALTER TABLE `usuario`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `cliente`
--
ALTER TABLE `cliente`
  ADD CONSTRAINT `FK_Cliente_Usuario` FOREIGN KEY (`idUsuario`) REFERENCES `usuario` (`id`);

--
-- Constraints for table `compra`
--
ALTER TABLE `compra`
  ADD CONSTRAINT `FK_Compra_Cliente` FOREIGN KEY (`idCliente`) REFERENCES `cliente` (`id`);

--
-- Constraints for table `detallecompra`
--
ALTER TABLE `detallecompra`
  ADD CONSTRAINT `FK_DetalleCompra_Compra` FOREIGN KEY (`idCompra`) REFERENCES `compra` (`id`),
  ADD CONSTRAINT `FK_DetalleCompra_Pelicula` FOREIGN KEY (`idPelicula`) REFERENCES `pelicula` (`id`);

--
-- Constraints for table `empleado`
--
ALTER TABLE `empleado`
  ADD CONSTRAINT `FK_Empleado_Usuario` FOREIGN KEY (`idUsuario`) REFERENCES `usuario` (`id`);

--
-- Constraints for table `pedido`
--
ALTER TABLE `pedido`
  ADD CONSTRAINT `FK_Pedido_Empleado` FOREIGN KEY (`idEmpleado`) REFERENCES `empleado` (`id`),
  ADD CONSTRAINT `FK_Pedido_Proveedor` FOREIGN KEY (`idProveedor`) REFERENCES `proveedor` (`id`);

--
-- Constraints for table `pedidodetalle`
--
ALTER TABLE `pedidodetalle`
  ADD CONSTRAINT `FK_PedidoDetalle_Pedido` FOREIGN KEY (`idPedido`) REFERENCES `pedido` (`id`);

--
-- Constraints for table `pelicula`
--
ALTER TABLE `pelicula`
  ADD CONSTRAINT `FK_Pelicula_Categoria` FOREIGN KEY (`idCategoria`) REFERENCES `categoria` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
